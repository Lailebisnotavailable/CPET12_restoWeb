from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.db import IntegrityError
from django.db.models import Q
##############c
from django.db import models
##############c
from .models import Accounts,FoodCatalog, Cart
from django.contrib.auth import logout
from django.core.paginator import Paginator
from django.contrib.auth.hashers import make_password
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

# Create your views here.

@csrf_exempt  # Allow CSRF exemption for AJAX requests, but consider using proper CSRF protection in production.
#######################c
def add_to_cart(request):
    if request.method == 'POST':
        print("AWYERUASYHDIASJHCNASVDKBCJFUGVHKDSJHDGFFDSHVJKVJKFHDBSSKSVDHJNFSBCJFHNDBVSDFSVKHFCNCJHNJDSVFRVSKHDNFHESKGRBJSDHKKLCBKD")
        print(type(FoodCatalog))  # Should print: <class 'django.db.models.base.ModelBase'>
        print(type(Cart))
        # Retrieve data from the request (POST data from AJAX call)
        data = json.loads(request.body)
        food_id = data.get('food_id')
        user_id = data.get('user_id')
        foodinstance = FoodCatalog.objects.get(FoodId=food_id)
        userinstance = Accounts.objects.get(AccountID=user_id)
        # Check if the user is logged in
        user = Accounts.objects.filter(AccountID=user_id).first()
        if not user:
            return JsonResponse({'error': 'User not logged in'}, status=400)

        # Check if the food item is already in the user's cart
        cart_item = Cart.objects.filter(AccountID=userinstance, FoodID=foodinstance).first()

        if cart_item:
            # If the item exists, increment the quantity
            cart_item.Quantity += 1
            cart_item.save()
            return JsonResponse({'exists': True, 'message': 'Item quantity incremented.'})
        else:
            # If the item doesn't exist, create a new cart item
            Cart.objects.create(AccountID=userinstance, FoodID=foodinstance, Quantity=1)
            return JsonResponse({'exists': False, 'message': 'Item added to cart.'})

    return JsonResponse({'error': 'Invalid request method.'}, status=400)
#################c



def Admin(request):
    if request.method == "POST":
        # If the dishId is present in the request, it's an edit operation
        dish_id = request.POST.get('dishId')  # This will hold the ID of the dish being edited

        if dish_id:  # This is an edit operation
            try:
                # Retrieve the existing food item from the database
                food_item = FoodCatalog.objects.get(id=dish_id)
                
                # Update fields with new data from the form
                food_item.FoodName = request.POST.get('dishName')
                food_item.FoodCategory = request.POST.get('dishCategory')
                food_item.FoodPrice = request.POST.get('dishPrice')
                food_item.FoodDescription = request.POST.get('dishDescription')

                # Update the image only if a new image was uploaded
                food_image = request.FILES.get('dishImage')
                if food_image:
                    food_item.FoodImage = food_image

                # Save the updated food item
                food_item.save()

            except IntegrityError:
                return HttpResponse("A food item with this name already exists. Please choose a different name.", status=400)

        else:  # This is an add operation (no dishId)
            # Get data from the form to create a new dish
            food_name = request.POST.get('dishName')
            food_category = request.POST.get('dishCategory')
            food_price = request.POST.get('dishPrice')
            food_image = request.FILES.get('dishImage')
            food_description = request.POST.get('dishDescription')

            # Validate that the Food Description is not empty
            if not food_description:
                return HttpResponse("Food description cannot be empty.", status=400)

            # Check if a food item with the same name exists (case insensitive)
            if FoodCatalog.objects.filter(Q(FoodName__iexact=food_name)).exists():
                return HttpResponse("A food item with this name already exists. Please choose a different name.", status=400)

            # Create a new FoodCatalog instance and save it to the database
            food_item = FoodCatalog(
                FoodName=food_name,
                FoodCategory=food_category,
                FoodPrice=food_price,
                FoodImage=food_image,
                FoodDescription=food_description
            )
            try:
                food_item.save()
            except IntegrityError:
                return HttpResponse("Error: A food item with this name already exists.", status=400)

        return redirect('Admin')  # Redirect back to the admin page after saving


    # Get all food items and paginate them
    food_items = FoodCatalog.objects.all()

    # Set up pagination (5 items per page)
    paginator = Paginator(food_items, 5)  # Show 5 food items per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    return render(request, 'Admin.html', {'page_obj': page_obj})    

#################################c
def Cart_Bag(request):

    # Check if the user is logged in by looking for 'user_id' in the session
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Log-In')  # Redirect to login if user is not logged in

    # Retrieve the logged-in user's data
    user = Accounts.objects.get(AccountID=user_id)
    user_cart_content = Cart.objects.filter(AccountID=user_id)
    print("ASDFLMJCHNLKMNDHKFSEJFNVBDHJHJSKLCFFHVKJKDDFJDHKSSDJFDHJJVMHJCKMVJKHJKKXCVBDJFHHJJCVHKBHJCVHFFKDC")
    


    context = {
        'user_cart_content' : user_cart_content,
        'first_name': user.FirstName,
        'last_name': user.LastName,
        'user_wallet_content': user.Wallet,
    }

    return render(request, 'Cart.html', context)
#################################################c
def Cashier(request):
    return render(request, 'Cashier.html')

def Checkout(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Log-In')  # Redirect to login if user is not logged in

    # Retrieve the logged-in user's data
    user = Accounts.objects.get(AccountID=user_id)

    block_lot = user.BlockLot if user.BlockLot != "None" else ""
    street = user.Street if user.Street != "None" else ""
    subdivision = user.Subdivision if user.Subdivision != "None" else ""
    barangay = user.Barangay if user.Barangay != "None" else ""
    city = user.City if user.City != "None" else ""
    province = user.Province if user.Province != "None" else ""

    # Add these values to the context
    context = {
    'first_name': user.FirstName,
    'last_name': user.LastName,
    'user_wallet_content': user.Wallet,
    'block_lot': block_lot,
    'street': street,
    'subdivision': subdivision,
    'barangay': barangay,
    'city': city,
    'province': province,
    }

    return render(request, 'Checkout.html', context)

def FAQs(request):
    return render(request, 'FAQs.html')

def FoodDis(request, FoodId):
    # Retrieve food details via FoodId
    food_item = get_object_or_404(FoodCatalog, FoodId=FoodId)
    
    # Retrieve user information if available
    user_id = request.session.get('user_id')
    
    if user_id:
        # If user is found in session, retrieve their details
        user = Accounts.objects.filter(AccountID=user_id).first()
        
        if user:
            context = {
                'user_id' : user.AccountID,
                'food_item': food_item,
                'first_name': user.FirstName,
                'last_name': user.LastName,
                'user_wallet_content': user.Wallet,
            }
        else:
            # If user is not found, treat as a guest
            context = {
                'food_item': food_item,
                'first_name': 'Guest',
                'last_name': '',
                'user_wallet_content': 0,
            }
    else:
        # If user_id is not in the session, treat as guest
        context = {
            'food_item': food_item,
            'first_name': 'Guest',
            'last_name': '',
            'user_wallet_content': 0,
        }

    # Render the food display page with the context
    return render(request, 'Food-Display.html', context)

def ForgetPass(request):
    return render(request, 'ForgetPass.html')

def warp(request):
    return render(request, 'Home-Page.html',)

def LogIn(request):
    if request.method == "POST":
        email = request.POST.get('email')  # Use get() to avoid MultiValueDictKeyError
        password = request.POST.get('password')
        
        # Check if both fields are provided
        if email and password:
            # Check if the email and password match a user in the database
            user = Accounts.objects.filter(Email=email, Password=password).first()
            
            if user:
                # Store user ID in the session
                request.session['user_id'] = user.AccountID

                context = {
                'first_name': user.FirstName,
                'last_name': user.LastName,
                'user_wallet_content': user.Wallet,
            }
                return redirect('Menu')  # Change to the name of your profile URL
            else:
                return render(request, 'Log-In.html', {'error_message': 'Invalid email or password.'})
        else:
            return render(request, 'Log-In.html', {'error_message': 'Successfully signed out.'})

    return render(request, 'Log-In.html')

def Menu(request):
    sort_category = request.GET.get('sort', 'all')  # Get the sort parameter from the request, default to 'all'
    search_query = request.GET.get('search', '')  # Get the search query from the request

    # Fetch all food items initially
    food_items = FoodCatalog.objects.all()

    # Filter by category if 'sort' value is provided
    if sort_category and sort_category != 'all':
        food_items = food_items.filter(FoodCategory__iexact=sort_category)  # Case-insensitive match

    # Filter by search query if it's provided
    if search_query:
        food_items = food_items.filter(FoodName__icontains=search_query)  # Case-insensitive search by food name

    # Handle case where no items match the filter
    if not food_items.exists():
        food_items = None

    # Check if the user is authenticated by checking the session
    user_id = request.session.get('user_id')  # Get user ID from session

    if user_id:
        user = Accounts.objects.filter(AccountID=user_id).first()  # Fetch the user using the session user_id
        if user:
            context = {
                'food_items': food_items,
                'first_name': user.FirstName,
                'last_name': user.LastName,
                'user_wallet_content': user.Wallet,  # Assuming Wallet is a field in the Accounts model
                'user': user,  # Include user object for profile image and other details
                'page_title': 'Menu',  # Title for the page
            }
        else:
            # If user not found, set default context for guest
            context = {
                'food_items': food_items,
                'first_name': 'Guest',
                'last_name': '',
                'user_wallet_content': 0,
                'user': None,
                'page_title': 'Menu',
            }
    else:
        # If user_id is not found in the session, treat as guest
        context = {
            'food_items': food_items,
            'first_name': 'Guest',
            'last_name': '',
            'user_wallet_content': 0,
            'user': None,
            'page_title': 'Menu',
        }

    # Render the menu page with the context
    return render(request, 'Menu.html', context)

def NewPass(request):
    return render(request, 'NewPassword.html')

def Payment(request):
    return render(request,'PaymentViewer.html')

def Profile(request):
    user_id = request.session.get('user_id')  # Get user ID from session

    if user_id:
        user = Accounts.objects.filter(AccountID=user_id).first()  # Fetch the user
        if user:
            # Prepare context variables for the greeting
            context = {
                'first_name': user.FirstName,
                'last_name': user.LastName,
                'user_wallet_content': user.Wallet,
                'user': user,  # Include user object for profile image and other details
                'page_title': 'Profile',
            }
            print(context)  # Debugging: Check if context is populated correctly

            if request.method == 'POST':
                if 'profile-image' in request.FILES:
                    profile_image = request.FILES['profile-image']
                    user.ProfileImage.save(profile_image.name, profile_image)  # Save the uploaded image

                # Update user profile
                user.FirstName = request.POST.get('first-name')
                user.LastName = request.POST.get('last-name')
                user.ContactNo = request.POST.get('contact-no')
                user.Email = request.POST.get('email')
                user.BlockLot = request.POST.get('block-lot')
                user.Street = request.POST.get('street')
                user.Subdivision = request.POST.get('subdivision')
                user.Barangay = request.POST.get('barangay')
                user.City = request.POST.get('city')
                user.Province = request.POST.get('province')
                # Handle password update logic if needed (be sure to hash it!)
                user.save()  # Save updated user information
                return redirect('Profile') 
            
            # Render the profile template with the context
            return render(request, 'Profile.html', context)  
        else:
            print("User not found.")  # Debugging: Check if user retrieval fails
            return render(request, 'Profile.html', {'error_message': 'User not found.'})
    else:
        return redirect('Log-In')  

def Register(request):
    error_message = None  # Initialize error_message to None

    if request.method == 'POST':
        firstName = request.POST.get('first-name')
        lastName = request.POST.get('last-name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm-password')
        birthday = request.POST.get('birthday')
        contactNo = request.POST.get('contact-number')
        secQuestion = request.POST.get('sec-question')
        secAnswer = request.POST.get('sec-answer')
        secPin = request.POST.get('sec-pin')

        print(f"First Name: {firstName}, Last Name: {lastName}, Email: {email}")  # Debug line
        print(f"Password: {password}, Confirm Password: {confirm_password}")  # Debug line

        # Email Authentication
        if Accounts.objects.filter(Email=email).exists():
            error_message = 'Email is already registered.'
            print("Email already exists")  # Debug line

        # Password matching
        elif password != confirm_password:
            error_message = 'Passwords didn’t match.'
            print("Passwords do not match")  # Debug line

        # If no error, proceed with registration
        if error_message is None:
            if secQuestion == 'custom':
                secQuestion = request.POST.get('custom-question')

            newAccount = Accounts(
                FirstName=firstName,
                LastName=lastName,
                Email=email,
                Password=password,  # Remember to hash this
                Birthday=birthday,
                ContactNo=contactNo,
                Sec_Question=secQuestion,
                Sec_Answer=secAnswer,
                Sec_Pin=secPin
            )

            try:
                newAccount.save()
                print("Account created successfully")  # Debug line
                return redirect('Log-In')  # Redirect to login or another page
            except IntegrityError as e:
                error_message = 'An error occurred while saving your data.'
                print(f"Error while saving: {e}")  # Debug line

    return render(request, 'Register.html', {'error_message': error_message})

def sign_out(request):
    logout(request)  # This logs out the user
    return redirect('Log-In')  # Redirect to the login page

def TopUp(request):
    # Check if the user is logged in by looking for 'user_id' in the session
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('Log-In')  # Redirect to login if user is not logged in

    # Retrieve the logged-in user's data
    user = Accounts.objects.get(AccountID=user_id)
    context = {
        'first_name': user.FirstName,
        'last_name': user.LastName,
        'user_wallet_content': user.Wallet,
    }

    return render(request, 'TopUp.html', context)

def Verify(request):
    return render(request, 'Verify.html')
















