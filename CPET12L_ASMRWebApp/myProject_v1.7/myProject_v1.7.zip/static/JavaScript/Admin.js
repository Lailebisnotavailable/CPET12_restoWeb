document.addEventListener('DOMContentLoaded', function() {
    // Get references to the toggle button and the arrow indicator
    const toggleButton = document.getElementById('toggleButton');
    const dishesTable = document.getElementById('dishesTable');
    const arrowIndicator = document.getElementById('arrowIndicator');
    
    // Check if the dropdown state is stored in localStorage
    const dropdownState = localStorage.getItem('dropdownState');
    const scrollPosition = localStorage.getItem('scrollPosition'); // Get the saved scroll position

    // If the state is saved as "open", set the table to be visible
    if (dropdownState === 'open') {
        dishesTable.style.display = 'table';
        arrowIndicator.textContent = '↓'; // Change the arrow to down
    } else {
        dishesTable.style.display = 'none';
        arrowIndicator.textContent = '→'; // Keep the arrow as right
    }

    // If a scroll position is stored, restore it
    if (scrollPosition) {
        window.scrollTo(0, scrollPosition); // Scroll to the saved position
    }

    // Event listener for the toggle button
    toggleButton.addEventListener('click', function() {
        if (dishesTable.style.display === 'none') {
            dishesTable.style.display = 'table'; // Show the table
            arrowIndicator.textContent = '↓'; // Change the arrow to down
            localStorage.setItem('dropdownState', 'open'); // Save the state as "open"
        } else {
            dishesTable.style.display = 'none'; // Hide the table
            arrowIndicator.textContent = '→'; // Change the arrow to right
            localStorage.setItem('dropdownState', 'closed'); // Save the state as "closed"
        }
    });

    // Store the scroll position when the user scrolls
    window.addEventListener('scroll', function() {
        localStorage.setItem('scrollPosition', window.scrollY); // Save the scroll position in localStorage
    });

    // Handle the Edit Button click event
    const editButtons = document.querySelectorAll('.editButton');
    
    // Disable all edit buttons initially when the page is loaded
    editButtons.forEach(button => {
        button.disabled = true; // Disable the Edit buttons
    });

    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = button.closest('tr'); // Get the row of the clicked button
            const cells = row.getElementsByTagName('td'); // Get the cells in the row

            // Disable all edit buttons temporarily
            editButtons.forEach(btn => btn.disabled = true);

            // Replace the content in each cell with the corresponding input field
            cells[1].innerHTML = `<input type="text" name="dishName" value="${cells[1].textContent}" required>`;
            cells[2].innerHTML = `<input type="number" name="dishPrice" value="${cells[2].textContent}" required>`;
            cells[3].innerHTML = `
                <select name="dishCategory" required>
                    <option value="Appetizer" ${cells[3].textContent === "Appetizer" ? 'selected' : ''}>Appetizer</option>
                    <option value="Main Dish" ${cells[3].textContent === "Main Dish" ? 'selected' : ''}>Main Dish</option>
                    <option value="Dessert" ${cells[3].textContent === "Dessert" ? 'selected' : ''}>Dessert</option>
                    <option value="Drinks" ${cells[3].textContent === "Drinks" ? 'selected' : ''}>Drinks</option>
                </select>
            `;
            cells[0].innerHTML = `<input type="file" name="dishImage" accept="image/*">`; // Allow uploading new image

            // Change the button text to "Save" or "Cancel"
            button.textContent = 'Save';

            // Change event to handle saving the changes or canceling
            button.addEventListener('click', function() {
                // Here you would send an AJAX request or submit the form to save the edited data
                // After saving, we can reset the row back to the normal state

                // Re-enable all edit buttons
                editButtons.forEach(btn => btn.disabled = false);
                
                // Reset the row back to normal state (for simplicity, just reset HTML)
                row.innerHTML = `
                    <td><img src="${cells[0].querySelector('input').value}" alt="${cells[1].querySelector('input').value}" width="50" height="50"></td>
                    <td>${cells[1].querySelector('input').value}</td>
                    <td>${cells[2].querySelector('input').value}</td>
                    <td>${cells[3].querySelector('select').value}</td>
                    <td><button class="editButton">Edit</button></td>
                `;
            });
        });
    });
});

    // Ensure the DOM is fully loaded before running JavaScript
    document.addEventListener('DOMContentLoaded', function() {
        const table = document.getElementById('dishesTable');
        const headers = table.querySelectorAll('th.sortable'); // Get all sortable headers
        const rows = Array.from(table.querySelectorAll('tbody tr')); // Get all table rows
    
        // Function to sort the table based on the selected column
        function sortTable(column, ascending = true) {
            const sortedRows = rows.sort((a, b) => {
                const cellA = a.querySelector(`td:nth-child(${column})`).textContent.trim();
                const cellB = b.querySelector(`td:nth-child(${column})`).textContent.trim();
    
                // Determine sorting order based on column type
                if (column === 2) { // Price column, sort as numbers
                    return ascending ? parseFloat(cellA) - parseFloat(cellB) : parseFloat(cellB) - parseFloat(cellA);
                } else { // Sort as strings (for name, category, etc.)
                    return ascending ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
                }
            });
    
            // Reattach the rows in the sorted order
            rows.forEach(row => table.querySelector('tbody').appendChild(row)); // Append sorted rows back
        }
    
        // Add click event listener to each sortable header
        headers.forEach(header => {
            header.addEventListener('click', function() {
                const column = header.dataset.column === 'name' ? 2 :
                               header.dataset.column === 'price' ? 3 :
                               header.dataset.column === 'category' ? 4 : 1;
                const isAscending = header.classList.contains('asc');
                const newOrder = isAscending ? 'desc' : 'asc';
    
                // Clear any previous sorting indicators
                headers.forEach(h => h.classList.remove('asc', 'desc'));
    
                // Toggle the sort order
                header.classList.add(newOrder);
    
                // Call the sort function
                sortTable(column, newOrder === 'asc');
            });
        });
    });
