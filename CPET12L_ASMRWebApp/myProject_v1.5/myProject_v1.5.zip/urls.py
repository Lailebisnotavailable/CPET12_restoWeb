from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from .views import sign_out
from . import views

urlpatterns = [
    path('Admin',views.Admin,name='Admin'),
    path('Cart',views.Cart,name='Cart'),
    path('Cashier',views.Cashier,name='Cashier'),
    path('Checkout',views.Checkout,name='Checkout'),
    path('FoodDis',views.FoodDis,name='FoodDis'),
    path('ForgetPass',views.ForgetPass,name='ForgetPass'), 
    path('',views.warp,name='warp'),
    path('Home-Page',views.warp,name='warp'),
    path('LogIn',views.LogIn,name='Log-In'),
    path('Menu',views.Menu,name='Menu'),
    path('NewPass',views.NewPass,name='NewPass'),
    path('Payment',views.Payment,name='Payment'),
    path('Profile/',views.Profile,name='Profile'),
    path('Register', views.Register, name='Register'),
    path('SignOut', sign_out, name='SignOut'),
    path('Verify',views.Verify,name='Verify'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)