document.addEventListener('DOMContentLoaded', function () {
    // Initialize Bootstrap Tabs
    const tabs = document.querySelectorAll('[data-bs-toggle="tab"]');
    tabs.forEach(tab => {
        tab.addEventListener('shown.bs.tab', function (e) {
            console.log(`Activated Tab: ${e.target.id}`);
        });
    });

    // Toggle dropdown and save state
    const toggleButton = document.getElementById('toggleButton');
    const dishesTable = document.getElementById('dishesTable');
    const arrowIndicator = document.getElementById('arrowIndicator');
    const dropdownState = localStorage.getItem('dropdownState');
    const scrollPosition = localStorage.getItem('scrollPosition');

    if (dropdownState === 'open') {
        dishesTable.style.display = 'table';
        arrowIndicator.textContent = '↓';
    } else {
        dishesTable.style.display = 'none';
        arrowIndicator.textContent = '→';
    }

    if (scrollPosition) {
        window.scrollTo(0, scrollPosition);
    }

    toggleButton.addEventListener('click', function () {
        if (dishesTable.style.display === 'none') {
            dishesTable.style.display = 'table';
            arrowIndicator.textContent = '↓';
            localStorage.setItem('dropdownState', 'open');
        } else {
            dishesTable.style.display = 'none';
            arrowIndicator.textContent = '→';
            localStorage.setItem('dropdownState', 'closed');
        }
    });

    window.addEventListener('scroll', function () {
        localStorage.setItem('scrollPosition', window.scrollY);
    });

    // Sorting functionality
    document.querySelectorAll('.sortable').forEach((th) => {
        th.addEventListener('click', function () {
            const table = th.closest('table');
            const rows = Array.from(table.querySelectorAll('tbody tr'));
            const index = Array.from(th.parentNode.children).indexOf(th);
            const isAscending = th.classList.contains('asc');
            const columnType = th.getAttribute('data-column');

            rows.sort((rowA, rowB) => {
                const cellA = rowA.cells[index].textContent.trim();
                const cellB = rowB.cells[index].textContent.trim();

                if (columnType === 'price') {
                    const priceA = parseFloat(cellA.replace(/[^\d.-]/g, ''));
                    const priceB = parseFloat(cellB.replace(/[^\d.-]/g, ''));
                    return isAscending ? priceA - priceB : priceB - priceA;
                } else if (columnType === 'name' || columnType === 'category') {
                    return isAscending ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
                }

                return 0;
            });

            rows.forEach(row => table.querySelector('tbody').appendChild(row));
            th.classList.toggle('asc', !isAscending);
            th.classList.toggle('desc', isAscending);
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
        // Edit Button functionality
        const editButtons = document.querySelectorAll('.editButton2');
    
        editButtons.forEach(button => {
            button.addEventListener('click', function () {
                const row = button.closest('tr');
                const cells = row.querySelectorAll('td');
    
                // Make all input fields editable if any
                const inputs = row.querySelectorAll('td input, td select, td textarea');
                
                // Check if inputs exist and make them editable
                if (inputs.length > 0) {
                    inputs.forEach(input => {
                        input.removeAttribute('readonly');
                        input.removeAttribute('disabled');
                    });
    
                    // Create the "Update" button
                    const updateButton = document.createElement('button');
                    updateButton.textContent = 'Update';
                    updateButton.classList.add('update-btn');
                    row.querySelector('td:last-child').appendChild(updateButton);
    
                    // Handle the "Update" button click
                    updateButton.addEventListener('click', function () {
                        const updatedValues = {};
                        inputs.forEach(input => {
                            updatedValues[input.name] = input.value;
                        });
    
                        console.log('Updated Dish:', updatedValues);
    
                        // Once update is clicked, make inputs read-only again and remove the "Update" button
                        inputs.forEach(input => {
                            input.setAttribute('readonly', true);
                            input.setAttribute('disabled', true);
                        });
    
                        updateButton.remove(); // Remove the "Update" button after updating
                    });
                }
            });
        });
    });
})